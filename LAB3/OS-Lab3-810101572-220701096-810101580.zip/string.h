#ifndef XV6_STRING_H
#define XV6_STRING_H

int strncmp(const char*, const char*, uint);

#endif